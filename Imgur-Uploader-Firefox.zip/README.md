# Imgur-Uploader-Firefox

Addon for user to upload image to imgur in Firefox 57

## Addon url
https://addons.mozilla.org/en-US/firefox/addon/imgur-upload/
